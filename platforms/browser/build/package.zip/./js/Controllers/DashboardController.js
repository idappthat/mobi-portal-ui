(function() {

    var app = angular.module('dashboard.controller', []);

    app.controller('DashboardController', ['$scope', function($scope) {

    }]);

})();
